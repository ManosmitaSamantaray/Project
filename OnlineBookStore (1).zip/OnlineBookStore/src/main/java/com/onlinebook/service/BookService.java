package com.onlinebook.service;

import java.util.List;

import com.onlinebook.entity.Book;
import com.onlinebook.entity.BookDTO;
import com.onlinebook.exception.BookNotFoundException;
import com.onlinebook.service.BookService;

public interface BookService {

	Book addBook(BookDTO bookDTO);
	
	Book updateBook(BookDTO bookDTO) throws BookNotFoundException;
	
	String deleteBook(BookDTO bookDTO);
	
	//List<Book> updateBook(BookDTO bookDTO, Integer id);

	//Book addBook(BookDTO bookDTO);
	
}
