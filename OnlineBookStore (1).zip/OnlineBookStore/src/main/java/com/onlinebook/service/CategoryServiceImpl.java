package com.onlinebook.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;

import com.onlinebook.entity.Book;
import com.onlinebook.entity.BookDTO;
import com.onlinebook.entity.Category;
import com.onlinebook.entity.CategoryDTO;
import com.onlinebook.exception.BookNotFoundException;
import com.onlinebook.exception.CategoryNotFoundException;
import com.onlinebook.repository.CategoryRepository;

@Service
public class CategoryServiceImpl implements CategoryService{
 
	private static final String String = null;
	@Autowired
	private CategoryRepository categoryRepository;
    private Integer categoryid;
    
    @Override
	public Category addCategory(CategoryDTO categoryDTO) {
		Category cat = new Category();
		
		cat.setCategoryid(categoryDTO.getCategoryid());
		cat.setName(categoryDTO.getName());
		
		return this.categoryRepository.save(cat);
	}
	
	@Override
	public Category updateCategory(CategoryDTO categoryDTO) throws CategoryNotFoundException {

		Optional<Category> categoryOpt = this.categoryRepository.findById(categoryDTO.getCategoryid());
		
		if(categoryOpt.isEmpty())
			throw new CategoryNotFoundException("category id does not exist to update");
		 
		   Category updateCategory = categoryOpt.get();
		   updateCategory.setName(categoryDTO.getName());
		
		return this.categoryRepository.save(updateCategory);
	}

	
	@Override
	public String deleteCategory(CategoryDTO categoryDTO) throws CategoryNotFoundException{
		
		Optional<Category> categoryOpt = this.categoryRepository.findById(categoryDTO.getCategoryid());
		 if(categoryOpt.isEmpty())
			 throw new CategoryNotFoundException("category id does not exist to delete");
		 
		 this.categoryRepository.deleteById(categoryid);
		 return "book id is deleted successfully";
	}

	@Override
	public List<Category> updateCategory(CategoryDTO categoryDTO, Integer categoryid) {

        List<Category> data = categoryRepository.findAll();
		return data;
	}
	
	//Get Single Data for edit, view
	@GetMapping("getSingleCategory/{categoryid}")
	 public Optional<Category> getCategoryById(Integer categoryid){
		return this.categoryRepository.findById(categoryid);
	}
  }
