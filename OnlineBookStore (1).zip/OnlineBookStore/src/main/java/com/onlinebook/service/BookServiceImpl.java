package com.onlinebook.service;

import com.onlinebook.service.BookService;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;

import com.onlinebook.entity.Book;
import com.onlinebook.entity.BookDTO;
import com.onlinebook.exception.BookNotFoundException;
import com.onlinebook.repository.BookRepository;

@Service
public class BookServiceImpl implements BookService{

@Autowired
private BookRepository bookRepository;
private Integer Id;

	public Book addBook(BookDTO bookDTO) {
		Book bk = new Book();
		
		bk.setId(bookDTO.getId());
		bk.setCategory_id(bookDTO.getCategory_id());
		bk.setDescription(bookDTO.getDescription());
		bk.setName(bookDTO.getName());
		
		return this.bookRepository.save(bk);
		//return this.bookRepository(bk);
	}
	
	public Book updateBook(BookDTO bookDTO) throws BookNotFoundException {

		Optional<Book> bookOpt = this.bookRepository.findById(bookDTO.getId());
		
		if(bookOpt.isEmpty())
			throw new BookNotFoundException("book id does not exist to update");
		 
		   Book updateBook = bookOpt.get();
		   updateBook.setName(bookDTO.getName());
		   updateBook.setDescription(bookDTO.getDescription());
		   updateBook.setCategory_id(bookDTO.getCategory_id());
		return this.bookRepository.save(updateBook);
	}

	public String deleteBook(BookDTO bookDTO) throws BookNotFoundException{
		
		Optional<Book> bookOpt = this.bookRepository.findById(bookDTO.getId());
		 if(bookOpt.isEmpty())
			 throw new BookNotFoundException("book id does not exist to delete");
		 
		 this.bookRepository.deleteById(Id);
		 return "book id is deleted successfully";
	}
	
	@GetMapping("/getSingleBook/{id}")
	public Optional<Book> getBookById(Integer id) {
//		Optional<User> singleUser= user.stream()
//				.filter(t -> userId.equals(t.userId()))
//				.findFirst()
//				.orElse(null);
		return this.bookRepository.findById(id);
	}
}