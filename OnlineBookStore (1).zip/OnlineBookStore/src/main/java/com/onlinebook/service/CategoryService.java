package com.onlinebook.service;

import java.util.List;

import com.onlinebook.entity.Book;
import com.onlinebook.entity.BookDTO;
import com.onlinebook.entity.Category;
import com.onlinebook.entity.CategoryDTO;
import com.onlinebook.exception.CategoryNotFoundException;


public interface CategoryService {
 Category addCategory(CategoryDTO categoryDTO);
	
	Category updateCategory(CategoryDTO categoryDTO) throws CategoryNotFoundException;
	
	List<Category> updateCategory(CategoryDTO categoryDTO, Integer categoryid);

	String deleteCategory(CategoryDTO categoryDTO) throws CategoryNotFoundException;

}
