package com.onlinebook.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.onlinebook.entity.Book;
import com.onlinebook.entity.Category;
import com.onlinebook.entity.CategoryDTO;
import com.onlinebook.exception.CategoryNotFoundException;
import com.onlinebook.service.CategoryServiceImpl;
import com.onlinebook.repository.CategoryRepository;

@RestController
@RequestMapping(value = "CategoryAPI")
@CrossOrigin(origins = "http://localhost:4200", methods= {RequestMethod.DELETE, RequestMethod.GET, RequestMethod.PUT,
		RequestMethod.POST })
public class CategoryController {

	@Autowired
	private CategoryServiceImpl categoryServiceImpl;

	@Autowired
	private CategoryRepository categoryRepository;
	
	@PostMapping("/addCategory")
	public Category addCat(@RequestBody CategoryDTO categoryDTO) {
		//categoryRepository.save(category);
		return this.categoryServiceImpl.addCategory(categoryDTO);
	}

	//Get Single value for edit, view
	@GetMapping("getSingleCategory/{categoryid}")
		public Optional<Category> getCategoryById(@PathVariable("categoryid")Integer categoryid){
			Optional<Category> data = this.categoryServiceImpl.getCategoryById(categoryid);
			return data;
		}
	
	
	@GetMapping("/categories")
	public List<Category> updateCategory() {
		List<Category> data = categoryRepository.findAll();
		return data;
	}

	@PutMapping("/updateCategory")
	public Category updateCategory(@RequestBody CategoryDTO categoryDTO) throws CategoryNotFoundException {
		return this.categoryServiceImpl.updateCategory(categoryDTO);
	}

	@DeleteMapping("/deleteCategory/{categoryid}")
	public String deleteCategory(@PathVariable("categoryid") Integer categoryid) throws CategoryNotFoundException {
		Optional<Category> categoryOpt = this.categoryRepository.findById(categoryid);

		if (categoryOpt.isEmpty())
			throw new CategoryNotFoundException("Category id does not exist to delete.");
		this.categoryRepository.deleteById(categoryid);
		return "Category deleted successfully";
	}
}
