package com.onlinebook.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.onlinebook.entity.Employee;
import com.onlinebook.exception.EmployeeNotFoundException;
import com.onlinebook.repository.EmployeeRepo;

import java.util.List;

@CrossOrigin(origins = "http://localhost:4200/")
@RestController
@RequestMapping("/api/v1")

public class EmployeeController {

    @Autowired
    private EmployeeRepo repo;

    @GetMapping("/employees")
    public List<Employee> getAllEmployee(){
        return repo.findAll();
    }

    @PostMapping("/add")
    public Employee addEmployee(@RequestBody Employee e){
        return repo.save(e);
    }

    @PutMapping("/updateEmp/{id}")
    public ResponseEntity<Employee> updateEmployee(@PathVariable Long id, @RequestBody Employee e)
    {
        Employee emp = repo.findById(id)
                .orElseThrow(() -> new EmployeeNotFoundException("Id does not exist"));
        emp.setFirstName(e.getFirstName());
        emp.setLastName(e.getLastName());
        emp.setEmailId(e.getEmailId());

        return ResponseEntity.ok(repo.save(emp));
    }

    @GetMapping("/{id}")
    public ResponseEntity<Employee> getEmployeeById(@PathVariable Long id){
        Employee e = repo.findById(id)
                .orElseThrow(() -> new EmployeeNotFoundException("Employee id does not exist"));
        return ResponseEntity.ok(e);
    }

    @DeleteMapping("/delete/{id}")
    public String deleteEmployee(@PathVariable Long id){
        repo.deleteById(id);
        return "deleted";
    }
}
