package com.onlinebook.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.onlinebook.entity.Book;
import com.onlinebook.entity.Category;

public interface CategoryRepository extends JpaRepository<Category, Integer>{

	
//	@Query(value = "SELECT  * FROM Category WHERE name as category_name", nativeQuery=true)
	
	Category save(Category category);
	
	Optional<Category> findById(Integer categoryid);
	
}


