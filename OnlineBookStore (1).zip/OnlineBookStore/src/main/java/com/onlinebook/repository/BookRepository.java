package com.onlinebook.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.onlinebook.entity.Book;

@Repository
public interface BookRepository extends JpaRepository<Book, Integer>{
   	
	@Query(value="select b.id,b.category_id,b.description, b.name, c.name as category_name from Book b, Category c "
			+ "where c.categoryid = b.category_id", nativeQuery = true) 
	public List<Book> getJoinData();
	Book save(Book book);

	Optional<Book> findById(Integer id);
}