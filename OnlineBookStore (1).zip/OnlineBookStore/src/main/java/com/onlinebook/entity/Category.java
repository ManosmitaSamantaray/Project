package com.onlinebook.entity;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Category {

		@Id
		@GeneratedValue
		private Integer categoryid;
		private String name;

		//@OneToOne(mappedBy = "category")
	    //private Category category;
		
		public Category() {
			super();
		}
		
		public Category(Integer categoryid, String name) {
			super();
			this.categoryid = categoryid;
			this.name = name;
		}
		
		public Integer getCategoryid() {
			return categoryid;
		}
		public void setCategoryid(Integer categoryid) {
			this.categoryid = categoryid;
		}
		
		public String getName() {
			return name;
		}
	    public void setName(String name) {
	    	this.name = name;
	    }

		  }
