package com.onlinebook.entity;

import java.util.List;

import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;

public class BookDTO {
	private Integer id;
	private String name;
	private String description;
	private Integer category_id;
	
	public BookDTO() {
		super();
	}
	
	public BookDTO(Integer id, String name, String description,Integer category_id) {
		super();
		this.id = id;
		this.category_id = category_id;
		this.description = description;
		this.name = name;
	}
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	
	public Integer getCategory_id() {
		return category_id;
	}
	public void setCategory_id(Integer category_id) {
		this.category_id = category_id;
	}
	
	public String getDescription() {
		return description;
		
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}