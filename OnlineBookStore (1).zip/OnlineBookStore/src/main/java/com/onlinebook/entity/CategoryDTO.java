package com.onlinebook.entity;

import java.util.List;

import javax.persistence.OneToMany;

public class CategoryDTO {
	private Integer categoryid;
	private String name;
	
//	@OneToMany
//	private List<Book> books;
	
	public CategoryDTO() {
		super();
	}
	
	public CategoryDTO(Integer categoryid, String name) {
		super();
		this.categoryid = categoryid;
		this.name = name;
	}
	
	public Integer getCategoryid() {
		return categoryid;
	}
	public void setCategoryid(Integer categoryid) {
		this.categoryid = categoryid;
	}
	
	public String getName() {
		return name;
	}
    public void setName(String name) {
    	this.name = name;
    }

}
