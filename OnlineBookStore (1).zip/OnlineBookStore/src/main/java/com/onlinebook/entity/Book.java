package com.onlinebook.entity;

import javax.persistence.CascadeType;
//import java.time.LocalDate;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="Book")
public class Book {
	@Id
	@GeneratedValue
	private Integer id;
	
	 //@ManyToMany(cascade= CascadeType.ALL)
	 @JoinColumn(name = "category_id")
	private Integer category_id;
	private String description;
	private String name;
	private String category_name;
	
//	public Book() {
//		super();
//	}
//	
//	public Book(Integer id, String name, String description,Integer category_id,String category_name) {
//		super();
//		this.id = id;
//		this.category_id = category_id;
//		this.description = description;
//		this.name = name;
//		this.category_name = category_name;
//	}
	
//	public Integer getId() {
//		return id;
//	}
//	public void setId(Integer id) {
//		this.id = id;
//	}
//	
//	public Integer getCategory_id() {
//		return category_id;
//	}
//	public void setCategory_id(Integer category_id) {
//		this.category_id = category_id;
//	}
//	
//	public String getDescription() {
//		return description;
//	}
//	public void setDescription(String description) {
//		this.description = description;
//	}
//	public String getName() {
//		return name;
//	}
//	public void setName(String name) {
//		this.name = name;
//	}
//	
//	public String getCategoryName() {
//		return category_name;
//	}
//	public void setCat3egoryName(String category_name) {
//		this.category_name = category_name;
//	}
}
