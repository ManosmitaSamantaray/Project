package com.kanbanboard;

//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.junit.jupiter.api.Assertions.assertThrows;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//
//import com.kanbanboard.entity.Project;
//import com.kanbanboard.exceptions.ProjectNotFoundException;
//import com.kanbanboard.service.ProjectService;

//import com.flowerapp.entity.Customer;
//import com.flowerapp.entity.CustomerDTO;
//import com.flowerapp.exception.CustomerNotFoundException;
//import com.flowerapp.service.CustomerService;

//@SpringBootTest
public class KanbanBoardApplicationTests {
//
//@Autowired
//private ProjectService projectService;
//
//@Test
//void addProjectTest() {
//	Project project = new Project(3, "kbproj", "demo project");
//	Project testProject = this.projectService.createProject(project);
//}
//
//@Test
//void updateProjectTest() {
//	ProjectDTO projectDTO = new ProjectDTO(3, "konbanproj", "demo3 proj");
//	assertThrows(ProjectNotFoundException.class, () -> this.projectService.updateProject(projectDTO));
// 
//}
//
//@Test
//void updateProjectTest2() {
//	ProjectDTO projectDTO = new ProjectDTO(1, "TestName", "myproj");
//	
//	try {
//		Project updatedProject = this.projectService.updateProject(projectDTO);
//		
//		assertEquals("TestName", updatedProject.getProjectName());
//	} catch (ProjectNotFoundException e) {
//		// TODO Auto-generated catch block
//		e.printStackTrace();
//	}
//
//	}
}
