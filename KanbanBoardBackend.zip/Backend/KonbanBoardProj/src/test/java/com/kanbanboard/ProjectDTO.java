package com.kanbanboard;

public class ProjectDTO {

	public ProjectDTO(int i, String string, String string2) {
		// TODO Auto-generated constructor stub
	}

}
