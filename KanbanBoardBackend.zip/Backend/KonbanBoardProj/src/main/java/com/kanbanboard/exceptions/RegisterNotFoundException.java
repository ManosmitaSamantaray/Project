package com.kanbanboard.exceptions;

public class RegisterNotFoundException extends Exception {
	
	public RegisterNotFoundException(String msg) {
		super(msg);
	}


}
