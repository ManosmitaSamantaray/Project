package com.kanbanboard.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.kanbanboard.entity.Register;
import com.kanbanboard.entity.RegisterDTO;
import com.kanbanboard.exceptions.RegisterNotFoundException;
import com.kanbanboard.repo.RegisterRepository;
import com.kanbanboard.service.RegisterServiceImpl;

@RestController
@RequestMapping(value = "RegisterAPI")
@CrossOrigin(origins = "http://localhost:4200", methods= {RequestMethod.DELETE, RequestMethod.GET, RequestMethod.PUT,
		RequestMethod.POST })
public class RegisterController {

	@Autowired
	private RegisterServiceImpl registerServiceImpl;

	@Autowired
	private RegisterRepository registerRepo;

	@PostMapping("/addUser")
	public Register createRegister(@RequestBody RegisterDTO registerDTO) {
		System.out.println("User controller  --- addUser");
		return this.registerServiceImpl.createRegister(registerDTO);
	}


	@GetMapping("/getRegister")
	public List<Register> updateRegister() {
		List<Register> data = registerRepo.findAll();
		return data;
	}
//	@GetMapping("/getSingleRegister/{userId}")
//	public  Optional<Register> getUserById(@PathVariable("userId") Integer userId) {
//		 Optional<Register> data = this.userServiceImpl.getUserById(userId);
//		return data;	
//	}
	
	@PutMapping("/updateRegister")
	public Register updateRegister(@RequestBody RegisterDTO registerDTO) throws RegisterNotFoundException {
		return this.registerServiceImpl.updateRegister(registerDTO);

	}

	@DeleteMapping("/deleteRegister/{userId}")
	public String deleteRegister(@PathVariable("userId") Integer userId) throws RegisterNotFoundException {
		Optional<Register> registerOpt = this.registerRepo.findById(userId);
		if (registerOpt.isEmpty())
			throw new RegisterNotFoundException("User id does not exist to delete.");
		this.registerRepo.deleteById(userId);
		return "Register deleted successfully";

	}
}
