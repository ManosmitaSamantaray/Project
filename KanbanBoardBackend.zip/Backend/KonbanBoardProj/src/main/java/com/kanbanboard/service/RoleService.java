package com.kanbanboard.service;

import com.kanbanboard.entity.Project;
import com.kanbanboard.entity.Role;
import com.kanbanboard.repo.RoleRepository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

@Service
public class RoleService {

    @Autowired
    private RoleRepository roleRepository;

    public Role createRole(Role role) {
        return roleRepository.save(role);
    }
    
    public Role getRole(Role role) {
    	return roleRepository.getOne("");
    }

	public List<Role> getRole() {
		List<Role> r1 = roleRepository.findAll(Sort.by(Sort.Direction.ASC, "id"));
		return null;
	}
}
