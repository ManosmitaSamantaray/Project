package com.kanbanboard.exceptions;

public class RoleNotFoundException {

}
