package com.kanbanboard.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.kanbanboard.entity.Register;

@Repository 
public interface RegisterRepository extends JpaRepository<Register, Integer>{

	Register save(Register register);

	Optional<Register> findByUserId(Integer userId);

}


