package com.kanbanboard.controller;

import com.kanbanboard.entity.Project;
import com.kanbanboard.entity.Role;
import com.kanbanboard.entity.User;
import com.kanbanboard.service.RoleService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

	@RestController
	@RequestMapping(value="/RoleAPI")
	@CrossOrigin(origins = "http://localhost:4200", methods= {RequestMethod.DELETE,RequestMethod.GET,RequestMethod.PUT,RequestMethod.POST})
     public class RoleController {
    @Autowired
    private RoleService roleService;
	private Object roleRepository;

    @PostMapping({"/createRole"})
    public Role createNewRole(@RequestBody Role role) {
        return roleService.createRole(role);
    }
    
//    @GetMapping("/getRole")
//	public Role getRole(@RequestBody Role role) {
//    	return roleService.getRole(role);
//	}
//    @GetMapping("/getRole")
//    public List<Role> updateRole(){
//    	List<Role> data = roleRepository.findAll();
//    	return data;
//    }
    @GetMapping("/getRole")
    public ResponseEntity<List<Role>> getRoles(){
    	List<Role> r = roleService.getRole();
    	ResponseEntity<List<Role>> r1 = new ResponseEntity<List<Role>>(r, HttpStatus.OK);
		return r1;
    }
}
