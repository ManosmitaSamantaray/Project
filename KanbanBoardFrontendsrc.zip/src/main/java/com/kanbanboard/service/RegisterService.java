package com.kanbanboard.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.kanbanboard.entity.Register;
import com.kanbanboard.entity.RegisterDTO;
import com.kanbanboard.exceptions.RegisterNotFoundException;


	public interface RegisterService {
		
		Register createRegister(RegisterDTO registerDTO);

		Register updateRegister(RegisterDTO registerDTO) throws RegisterNotFoundException;

		String deleteRegister(RegisterDTO registerDTO);

		public List<Register> showAllRegisters();
		 Optional<Register> getRegisterById(Integer userId) throws RegisterNotFoundException;

		List<Register> updateRegister(RegisterDTO registerDTO, Integer userId);
		

		List<Register> getAllRegisters();
	}



