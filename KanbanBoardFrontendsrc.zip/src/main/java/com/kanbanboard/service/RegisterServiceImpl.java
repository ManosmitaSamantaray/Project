package com.kanbanboard.service;

import com.kanbanboard.entity.Register;
import com.kanbanboard.entity.RegisterDTO;
import com.kanbanboard.exceptions.RegisterNotFoundException;
import com.kanbanboard.repo.RegisterRepository;

import java.util.List;
	import java.util.Optional;

	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Service;
	import org.springframework.web.bind.annotation.DeleteMapping;
	import org.springframework.web.bind.annotation.GetMapping;
	import org.springframework.web.bind.annotation.PostMapping;
	import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.data.domain.Sort;
	

	@Service // @Component
	public class RegisterServiceImpl implements RegisterService {

		@Autowired
		private RegisterRepository registerRepo;

		public Register createRegister(RegisterDTO registerDTO) {
			System.out.println("UserServiceImpl -- addUser");

			Register cust = new Register();

			cust.setUserId(registerDTO.getUserId());
			cust.setFirstname(registerDTO.getFirstname());
			cust.setLastname(registerDTO.getLastname());
			cust.setEmail(registerDTO.getEmail());
			cust.setPwd(registerDTO.getPwd());
			

			System.out.println(cust);
			return this.registerRepo.save(cust);
		}

		//@PutMapping("/updateUser/{userId}")
		public Register updateUser(RegisterDTO registerDTO) throws RegisterNotFoundException {

			Optional<Register> registerOpt = this.registerRepo.findById(registerDTO.getUserId());
			if (registerOpt.isEmpty())
				throw new RegisterNotFoundException("User id does not exist to update.");

			Register updateRegister = registerOpt.get();
			updateRegister.setFirstname(registerDTO.getFirstname());
			updateRegister.setLastname(registerDTO.getLastname());
			updateRegister.setEmail(registerDTO.getEmail());
			updateRegister.setPwd(registerDTO.getPwd());
			
			return this.registerRepo.save(updateRegister);
		}

		//@PostMapping("/getData")
		public List<Register> updateRegister(RegisterDTO registerDTO, Integer userId) {
			System.out.println("User controller  --- getUser");
			List<Register> data = registerRepo.findAll();
			return data;
		}

		//@DeleteMapping("/deleteUsmer/{userId}")
		public String deleteRegister(Integer userId) throws RegisterNotFoundException {
			Optional<Register> registerOpt = this.registerRepo.findById(userId);
			if (registerOpt.isEmpty())
				throw new RegisterNotFoundException("User id does not exist to delete.");
			this.registerRepo.deleteById(userId);
			String messageBody = "{message:'User deleted successfully'}";
			return messageBody;
			//return "User deleted successfully";
		}

		public List<Register> showAllRegisters() {

			return this.registerRepo.findAll(Sort.by(Sort.Direction.ASC,"userId"));
		}
         
//		@GetMapping("/getSingleUser/{userId}")
//		public Optional<Register> getRegisterById(Integer userId) {
////			Optional<User> singleUser= user.stream()
////					.filter(t -> userId.equals(t.userId()))
////					.findFirst()
////					.orElse(null);
//			return this.registerRepo.findById(userId);
//		}

		@Override
		public String deleteRegister(RegisterDTO registerDTO) {
			// TODO Auto-generated method stub
			return null;
		}

		
		@Override
		public List<Register> getAllRegisters() {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public Register updateRegister(RegisterDTO registerDTO) throws RegisterNotFoundException {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public Optional<Register> getRegisterById(Integer userId) throws RegisterNotFoundException {
			// TODO Auto-generated method stub
			return null;
		}

	}
