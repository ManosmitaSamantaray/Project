export class Register {
    userId !: Number;
    //roleId !: Number;
    firstname!: String;
    lastname!: String;
    email!:String;
    pwd!:String;
    rpwd!:String;

}
