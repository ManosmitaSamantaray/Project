import { Component, OnInit } from '@angular/core';
//import {NgbPaginationModule, NgbAlertModule} from '@ng-bootstrap/ng-bootstrap';
import { Project } from '../project';
import { ProjectService } from '../project.service';
import { environment } from 'src/environments/environment';
import { Router } from '@angular/router';
declare var $: any; 

@Component({
  selector: 'app-project-list',
  templateUrl: './project-list.component.html',
  styleUrls: ['./project-list.component.css']
})
export class ProjectListComponent implements OnInit {

  projects!: Project[];
 
  constructor(private projectService: ProjectService,private router:Router) { }
   //this.projectService.getProjectList().subscribe();
   ngOnInit(){
    this.getProjectList();
    //console.log("username:" +environment.setUsername)
    // if(environment.AuthenticateUser= false){
    //   this.router.navigateByUrl('/');
    // }
    $(document).ready(function() {
      setTimeout(function() {
        $('#kb_listing_table').dataTable();  
        $('.kb-listing-data-table').show();          
      }, 200);
  });
}
 
getProjectList() {
  this.projectService.getProjectList().subscribe((response: any)=>{
    this.projects = response;
 });
}
projectDeleted(Id: Number){
  if(confirm("Are you sure want to delete this record?")) {    
      this.projectService.deleteProject(Id).subscribe((response: any)=>{  
    });      
    location.reload();
  }
  else
  {
    location.reload();
  }
}
}
