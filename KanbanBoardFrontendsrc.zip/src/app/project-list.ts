export class ProjectList {
    id! : Number;
    projectName!:String;
    description!:String;
}
