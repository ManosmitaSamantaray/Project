import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Login } from './login';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

 constructor(private http: HttpClient) { }
  baseUrl = environment.API_BASE_URL;
  userSignIn(login: Login){
    return this.http.post(this.baseUrl + "/UserAPI/userSignIn", login);
    console.log(login)
  }
}
