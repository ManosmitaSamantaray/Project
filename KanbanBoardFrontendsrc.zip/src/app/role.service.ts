import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Role } from './role';

@Injectable({
  providedIn: 'root'
})
export class RoleService {
  [x: string]: any;
  getAllRoles() {
    throw new Error('Method not implemented.');
  }
  constructor(private http: HttpClient) { }
  baseUrl = environment.API_BASE_URL;
  createRole(role: Role){
    return this.http.post(this.baseUrl + "/RoleAPI/createRole", role);
  }
  getRoleList(){
     return this.http.get(this.baseUrl+ "/RoleAPI/getRole");
  }

  updateRole(role: Role){
    return this.http.put(this.baseUrl+ "/RoleAPI/UpdateRole", role);
  }
  deleteRole(roleId: Number){
    return this.http.delete(this.baseUrl+ "/RoleAPI/RemoveRole/"+roleId);
  }
}