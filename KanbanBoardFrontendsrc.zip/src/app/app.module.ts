import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegisterComponent } from './components/register/register.component';
import { RegisterService } from './register.service';
import { UserregisterlistComponent } from './userregisterlist/userregisterlist.component';
//import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AboutComponent } from './about/about.component';
import { HomeComponent } from './home/home.component';
import { ContactComponent } from './contact/contact.component';
import { ProjectComponent } from './project/project.component';
import { LandingPageComponent } from './landing-page/landing-page.component';
import { LoginComponent } from './login/login.component';
import { ProjectListComponent } from './project-list/project-list.component';
import { RoleComponent } from './role/role.component';
import { RoleService } from './role.service';
import { ProjectService } from './project.service';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HeaderComponent } from './header/header.component';
import { RoleListComponent } from './role-list/role-list.component';

@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    UserregisterlistComponent,
    ProjectComponent,
    ProjectListComponent,
    AboutComponent,
    HomeComponent,
    ContactComponent,
    RoleComponent,
    LandingPageComponent,
    LoginComponent,
    HeaderComponent,
    RoleListComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule, FormsModule,

    RouterModule.forRoot([
      { path: 'register', component: RegisterComponent },
      { path: 'userregisterlist', component: UserregisterlistComponent },
      { path: 'about', component: AboutComponent },
      { path: 'home', component: HomeComponent },
      { path: 'contact', component: ContactComponent },
      { path: 'project', component: ProjectComponent },
      { path: 'landing-page', component: LandingPageComponent },
      { path: 'login', component: LoginComponent },
      { path: 'project-list', component: ProjectListComponent },
      { path: 'role', component: RoleComponent },
      { path: 'role-list', component: RoleListComponent },
      { path: 'header', component: HeaderComponent },
     
      { path: '', component: LoginComponent },
     // { path: 'login', component: LoginComponent },
      { path: 'home', component: HomeComponent },
    ]),
    NgbModule,
   
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
