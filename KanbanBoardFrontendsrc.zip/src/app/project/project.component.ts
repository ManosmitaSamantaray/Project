import { preserveWhitespacesDefault } from '@angular/compiler';
import {Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params} from '@angular/router';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Project } from '../project';
import { ProjectService } from '../project.service';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
@Component({
  selector: 'app-project',
  templateUrl: './project.component.html',
  styleUrls: ['./project.component.css']
})

export class ProjectComponent implements OnInit {
  
  project = new Project();
  currentAction = "";
  constructor(private projectService:ProjectService, private router:Router, private projectRoute:ActivatedRoute) { 
    this.projectRoute.queryParams.subscribe(params =>{
     this.currentAction = params['action'];
     if(params['action'] == "edit" || params['action'] == "view"){
      this.getSingleProject(params['Id'])
     } 
    })
  }
  
  ngOnInit() {

  }
  
  projectForm = new FormGroup({
    projectName: new FormControl("", [Validators.required,Validators.minLength(2), Validators.pattern("[a-zA-Z].*")]),
    description: new FormControl("", [Validators.required,Validators.minLength(2), Validators.pattern("[a-zA-Z].*")]),
  });

  getSingleProject(Id: Number) {
    this.projectService.singleProject(Id).subscribe((response: any)=>{
      this.project = response;
   });
  }
  projectSubmited(){
    this.projectService.createProject(this.project).subscribe((response) => {
      console.log(response);
      alert("project details submitted successfully");
      this.router.navigateByUrl('/project-list');
    });
  }
  get ProjectName(): FormControl{
    return this.projectForm.get("projectName") as FormControl;
  }

  get Description(): FormControl{
    return this.projectForm.get("description") as FormControl;
  }
}
