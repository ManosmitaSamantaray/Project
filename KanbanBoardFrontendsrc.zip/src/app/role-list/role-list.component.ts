import { Component, OnInit } from '@angular/core';
import { Role } from '../role';
import { ProjectService } from '../project.service';
import { environment } from 'src/environments/environment';
import { Router } from '@angular/router';
import { RoleService } from '../role.service';
declare var $: any; 

@Component({
  selector: 'app-role-list',
  templateUrl: './role-list.component.html',
  styleUrls: ['./role-list.component.css']
})
export class RoleListComponent implements OnInit {

  roles!: Role[];
 
  constructor(private roleService: RoleService,private router:Router) { }
   //this.projectService.getProjectList().subscribe();
   ngOnInit(){
    this.getRoleList();

    if(environment.AuthenticateUser= false){
      this.router.navigateByUrl('/');
    }
    
    $(document).ready(function() {
      setTimeout(function() {
        $('#kb_listing_table').dataTable();  
        $('.kb-listing-data-table').show();          
      }, 200);
  });
}
getRoleList() {
  this.roleService.getRoleList().subscribe((response: any)=>{
    this.roles = response;
 });
}
roleDeleted(roleId: Number){
  if(confirm("Are you sure want to delete this record?")) {    
      this.roleService.deleteRole(roleId).subscribe((response: any)=>{  
    });      
    location.reload();
  }
  else
  {
    location.reload();
  }
}
}
