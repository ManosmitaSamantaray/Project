export class Login {
    email!:String;
    pwd!:String;
}
