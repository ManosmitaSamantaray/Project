import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Register } from './register';

@Injectable({
  providedIn: 'root'
})
export class RegisterService {
  
  constructor(private http: HttpClient) { }
  baseUrl = environment.API_BASE_URL;
  createUser(register: Register){
    return this.http.post(this.baseUrl + "/UserAPI/addUser", register);
  }
 updateUser(register: Register){
    return this.http.put(this.baseUrl + "/UserAPI/updateUser", register);
 }

 getUserRegisterList(){
  return this.http.get(this.baseUrl+ "/UserAPI/getUser");
}
singleUser(userId: Number){
  return this.http.get(this.baseUrl+ "/UserAPI/getSingleUser/"+userId);
 }
deleteUser(userId: Number){
 return this.http.delete(this.baseUrl+ "/UserAPI/deleteUser/"+userId);
}
}
