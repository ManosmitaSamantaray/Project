import { preserveWhitespacesDefault } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Role } from '../role';
import { RoleService } from '../role.service';

@Component({
   selector: 'app-role',
  templateUrl: './role.component.html',
  styleUrls: ['./role.component.css']
})
export class RoleComponent implements OnInit {

 role = new Role();
 router: any;
  constructor(private roleService:RoleService) { }

  ngOnInit() {

  }

  roleForm = new FormGroup({
    roleName: new FormControl("", [Validators.required,Validators.minLength(2), Validators.pattern("[a-zA-Z].*")]),
    roleDescription: new FormControl("", [Validators.required,Validators.minLength(2), Validators.pattern("[a-zA-Z].*")]),
  });

  roleSubmited(){
    this.roleService['createRole'](this.role).subscribe((response) => {
      console.log(response);
      alert("role submitted successfully");
      this.router.navigateByUrl('/role-list');
    });
  }
  get RoleName(): FormControl{
    return this.roleForm.get("roleName") as FormControl;
  }

  get RoleDescription(): FormControl{
    return this.roleForm.get("roleDescription") as FormControl;
  }
}
