import { preserveWhitespacesDefault } from '@angular/compiler';
import {Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params} from '@angular/router';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Register } from 'src/app/register';
import { RegisterService } from 'src/app/register.service';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
// import { Role } from '../project';
// import { RoleService } from '../project.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
  
})
export class RegisterComponent implements OnInit {
  //roles!: Role[];
  register = new Register();
  repeatPass!: string;
  currentAction = "";  
  constructor(private registerService:RegisterService, private router:Router, private registerRoute:ActivatedRoute) { 
    this.registerRoute.queryParams.subscribe(params => {
      this.currentAction = params['action'];
      if(params['action'] == "edit" || params['action'] == "view"){
        this.getSingleUser(params['userId'])
      }
  
    })
  }

  ngOnInit() {
// this.getRoleList();
  }

  // getRoleList() {
  //   this.projectService.getProjectList().subscribe((response: any)=>{
  //     this.roles = response;
  //  });
  // }

  registerForm = new FormGroup({
    //roleId : new 
    firstname: new FormControl("", [Validators.required, Validators.minLength(2), Validators.pattern("[a-zA-Z].*")]),
    lastname: new FormControl("", [Validators.required, Validators.minLength(2), Validators.pattern("[a-zA-Z].*")]),
    email: new FormControl("", [Validators.required, Validators.email]),
    pwd: new FormControl("", [Validators.required, Validators.minLength(6), Validators.maxLength(15),]),
    rpwd: new FormControl(''),  
  });

  getSingleUser(userId: Number) {
    this.registerService.singleUser(userId).subscribe((response: any)=>{
      this.register = response;
   });
  }

  registerSubmited(){
          if(this.PWD.value == this.RPWD.value){
            console.log(this.registerForm.valid);
            this.repeatPass = 'none'
          }else{
            this.repeatPass = 'inline'
          }
    

      this.registerService.createUser(this.register).subscribe((response) => {
        console.log(response);
        alert("User Data is added successfully");
        this.router.navigateByUrl('/userregisterlist');
      });
      }

  //get RoleId(): FormControl{
    //return this.registerForm.get("firstname") as FormControl; 
  //} 
  get FirstName(): FormControl{
    return this.registerForm.get("firstname") as FormControl;
  }
  get LastName(): FormControl{
    return this.registerForm.get("lastname") as FormControl;
  }
  get Email(): FormControl{
    return this.registerForm.get("email") as FormControl;
  }
  get PWD(): FormControl{
    return this.registerForm.get("pwd") as FormControl;
  }
  get RPWD(): FormControl{
    return this.registerForm.get("rpwd") as FormControl;
  }
}