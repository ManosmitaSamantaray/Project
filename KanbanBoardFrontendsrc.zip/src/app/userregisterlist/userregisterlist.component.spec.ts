import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserregisterlistComponent } from './userregisterlist.component';

describe('UserregisterlistComponent', () => {
  let component: UserregisterlistComponent;
  let fixture: ComponentFixture<UserregisterlistComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserregisterlistComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UserregisterlistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
