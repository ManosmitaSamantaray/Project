import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { ProjectList } from './project-list';

@Injectable({
  providedIn: 'root'
})
export class ProjectListService {

  constructor(private http: HttpClient) { }
  baseUrl = environment.API_BASE_URL;
  getProjectList(){
    return this.http.get(this.baseUrl+ "/projects");
  }
}
