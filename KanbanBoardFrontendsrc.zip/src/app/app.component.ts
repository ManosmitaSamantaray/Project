import { Component, EnvironmentInjector } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Router } from '@angular/router';
declare var $: any;

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'kan-ban-proj';
  setAuthenticateUser = environment.AuthenticateUser;
  setFirstUser = environment.setUsername;
  constructor(private router:Router) { }

  // ngOnInit(){
  //   this.setAuthenticateUser = environment.AuthenticateUser;

  // }
  logout(){
    environment.AuthenticateUser = false;
    this.setAuthenticateUser = false;
    $(document).ready(function() {
      $('.kb-hdr-sh').hide();
    })
    this.router.navigateByUrl('/');
  }
}


// constructor(private http: HttpClient, private router: Router) {
//   this.app.authenticate(undefined, undefined);
// }
// logout() {
//   this.http.post('logout', {}).finally(() => {
//       this.app.authenticated = false;
//       this.router.navigateByUrl('/login');
//   }).subscribe();
// }