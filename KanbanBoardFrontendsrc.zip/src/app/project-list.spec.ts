import { ProjectList } from './project-list';

describe('ProjectList', () => {
  it('should create an instance', () => {
    expect(new ProjectList()).toBeTruthy();
  });
});
