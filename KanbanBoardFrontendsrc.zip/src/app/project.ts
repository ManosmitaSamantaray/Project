export class Project {
    id!:Number;
    projectName!:String;
    description!:String;
}
