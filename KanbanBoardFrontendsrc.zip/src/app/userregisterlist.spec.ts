import { Userregisterlist } from './userregisterlist';

describe('Userregisterlist', () => {
  it('should create an instance', () => {
    expect(new Userregisterlist()).toBeTruthy();
  });
});
