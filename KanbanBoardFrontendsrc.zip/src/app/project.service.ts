import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Project } from './project';

@Injectable({
  providedIn: 'root'
})
export class ProjectService {
  [x: string]: any;
  getAllProjects() {
    throw new Error('Method not implemented.');
  }
  constructor(private http: HttpClient) { }
  baseUrl = environment.API_BASE_URL;
  createProject(project: Project){
    return this.http.post(this.baseUrl + "/ProjectAPI/AddProject", project);
  }
  updateProject(project: Project){
    return this.http.put(this.baseUrl+ "/ProjectAPI/UpdateProject", project);
  }
  getProjectList(){
     return this.http.get(this.baseUrl+ "/ProjectAPI/getProject");
  }
  singleProject(Id: Number){
    return this.http.get(this.baseUrl+ "/ProjectAPI/getSingleProject/"+Id);
   }
  deleteProject(projectId: Number){
    return this.http.delete(this.baseUrl+ "/ProjectAPI/RemoveProject/"+projectId);
  }
}
